﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LecturerClaimsSystem.Migrations
{
    /// <inheritdoc />
    public partial class AddStatusToLecturer : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "Lecturers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Status",
                table: "Lecturers");
        }
    }
}
