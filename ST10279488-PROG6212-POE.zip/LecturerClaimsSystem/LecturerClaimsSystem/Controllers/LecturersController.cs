﻿using LecturerClaimsSystem.Models;
using LecturerClaimsSystem.Services;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using static System.Net.Mime.MediaTypeNames;

namespace LecturerClaimsSystem.Controllers
{
    public class LecturersController : Controller
    {
        private readonly ApplicationDbContext context;
        private readonly IWebHostEnvironment environment;

        public string Name { get; private set; }
        public string Email { get; private set; }

        public LecturersController(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            this.context = context;
            this.environment = environment;
        }
        public IActionResult Index()
        {
            var lecturers = context.Lecturers.OrderByDescending(p => p.Id).ToList();
            return View(lecturers);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(LecturerDto lecturerDto)
        {
        
           

            if(!ModelState.IsValid)
            {
                return View(lecturerDto);
            }
            return RedirectToAction("Index","Lecturers");
        }

        public IActionResult Verify(int id)
        {
            var lecturer = context.Lecturers.Find(id);

            if (lecturer == null)
            {
                return RedirectToAction("Index", "Products");
            }

            var lecturerDto = new LecturerDto()
            {
                Name = lecturer.Name,
                Email = lecturer.Email,
                Module = lecturer.Module,
                HoursWorked = lecturer.HoursWorked,
                HourlyRate = lecturer.HourlyRate,
                
            };


            ViewData["LecturerId"] = lecturer.Id;
            ViewData["CreateAt"] = lecturer.CreatedAt.ToString("MM/dd/yyyy");

            return View(lecturerDto);
        }


        [HttpPost]
        public IActionResult Verify(int id, LecturerDto lecturerDto)
        {
            var lecturer = context.Lecturers.Find(id);

            if (lecturer == null)
            {
                return RedirectToAction("Index", "Products");
            }


            if(!ModelState.IsValid)
            {
                ViewData["LecturerId"] = lecturer.Id;
                ViewData["CreateAt"] = lecturer.CreatedAt.ToString("MM/dd/yyyy");

                return View(lecturerDto);
            }

            lecturer.Name = lecturer.Name;
            lecturer.Email = lecturer.Email;
            lecturer.Module = lecturer.Module;
            lecturer.HoursWorked = lecturer.HoursWorked;
            lecturer.HourlyRate = lecturer.HourlyRate;

            context.SaveChanges();

            return RedirectToAction("Index", "Lecturers");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(LecturerDto lecturerDto)
        {
            
                if (ModelState.IsValid)
                {
                Console.WriteLine("Here");
                    lecturerDto.Status = "Pending"; // Set default status
                    context.Add(lecturerDto);
                    await context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                return View(lecturerDto);
            
        }
        public async Task<IActionResult> Accept(int id)
        {
            var lecturerDto = context.Lecturers.Find(id);
            if (lecturerDto == null)
            {
                return NotFound();
            }

            lecturerDto.Status = "Accepted";
            context.Update(lecturerDto);
            await context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Claim claim)
        {
            if (ModelState.IsValid)
            {
                // Calculate the Final Payment
                claim.FinalPayment = claim.HoursWorked * claim.HourlyRate;

                context.Add(claim);
                await context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(claim);

        }

        }
}
