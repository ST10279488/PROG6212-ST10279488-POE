﻿using System.ComponentModel.DataAnnotations;

namespace LecturerClaimsSystem.Models
{
    public class LecturerDto
    {
        [Required]
        public string Name { get; set; } = "";
        [Required]
        public string Email { get; set; } = "";
        [Required] 
        public string Module { get; set; } = "";
        [Required]
        [Range(0, double.MaxValue, ErrorMessage = "Hours Worked must be a positive number.")]
        public int HoursWorked { get; set; }
        [Required]
        [Range(0, double.MaxValue, ErrorMessage = "Hourly Rate must be a positive number.")]
        public decimal HourlyRate { get; set; }
        public IFormFile? Document { get; set; }
        public string Status { get; internal set; } = "";
        public decimal FinalPayment { get; set; }
       
    }
}

