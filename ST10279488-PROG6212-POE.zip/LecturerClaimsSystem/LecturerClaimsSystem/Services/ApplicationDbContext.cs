﻿using LecturerClaimsSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace LecturerClaimsSystem.Services
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options) 
        { 

        }
        public DbSet<Lecturer> Lecturers {  get; set; }
        public object Lecturer { get; internal set; }
    }
}
